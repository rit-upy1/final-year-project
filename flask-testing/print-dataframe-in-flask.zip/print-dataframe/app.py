from flask import Flask,render_template,request
import sys
sys.path.append('/home/ritvik/Final Year Project/aks/src')
sys.path.append('/home/ritvik/Final Year Project/video-game-recommender')
sys.path.append('/home/ritvik/Final Year Project/movie-recommender')
sys.path.append('/home/ritvik/Final Year Project/aks/src')
#import emotions
from recommend import get_game_on_mood
from headless_main import get_movie_on_genre, get_genre_based_on_mood
from emotions import display


app = Flask(__name__)

@app.route('/',methods = ['POST','GET'])
def index():
    if request.method == "POST":
        mood = display()

        #just uncomment the below line for the input box to work
        #mood = request.form['content']
        game_recommendations = get_game_on_mood(mood.lower())
        game_recommendations.drop(columns = ['combined'],inplace = True)
        movie_recommendations = get_movie_on_genre(get_genre_based_on_mood(mood))
        
        return render_template('index.html', game_recommendations=[game_recommendations.to_html(classes='data', index=False)],
        game_columns=game_recommendations.columns.values, movie_recommendations=[movie_recommendations.to_html(classes='data', index=False)],
        movie_columns = movie_recommendations.columns.values)
    else:    
        return render_template('index.html')

app.run(debug=True)
